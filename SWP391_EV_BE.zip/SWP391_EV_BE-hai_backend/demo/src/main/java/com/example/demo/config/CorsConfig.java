package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig {

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins(
                                "https://orthopterous-unwieldable-kristal.ngrok-free.dev",
                                "https://0f150aea0297.ngrok-free.app",
                                "https://vallate-enzootically-sterling.ngrok-free.dev",
                                "https://unbackward-imperviously-hiram.ngrok-free.dev",
                                "http://localhost:3000",
                                "http://localhost:5173",
                                "https://caleb-idiomatic-milissa.ngrok-free.dev",
                                "unentangleable-overinstructively-elle.ngrok-free.dev",
                                "http://127.0.0.1:3000")
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS")
                        .allowedHeaders("*")
                        .allowCredentials(true)
                        .maxAge(3600);
            }
        };
    }
}